create materialized view all_courses_materialized as
SELECT courses.id,
       courses.name,
       courses.start_date,
       courses.end_date,
       courses.course_level,
       courses.is_started,
       courses.instructor_id
FROM courses;

alter materialized view all_courses_materialized owner to postgres;

