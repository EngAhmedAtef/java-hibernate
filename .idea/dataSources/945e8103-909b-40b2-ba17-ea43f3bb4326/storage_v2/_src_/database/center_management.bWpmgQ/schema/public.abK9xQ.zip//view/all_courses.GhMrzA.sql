create view all_courses (id, name, start_date, end_date, course_level, is_started, instructor_id) as
SELECT courses.id,
       courses.name,
       courses.start_date,
       courses.end_date,
       courses.course_level,
       courses.is_started,
       courses.instructor_id
FROM courses;

alter table all_courses
    owner to postgres;

